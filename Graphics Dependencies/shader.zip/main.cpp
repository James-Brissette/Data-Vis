#include <GL/glew.h>
#include <GL/freeglut.h>
#include <iostream>
#include <cyCore.h>
#include <cyPoint.h>
#include <cyMatrix.h>
#include <cyTriMesh.h>
#include <cyGL.h>

using namespace std;

cy::TriMesh teapot;
cy::GLSLProgram ShaderProgram;
cy::GLSLShader vertexShaderObj;
cy::GLSLShader fragmentShaderObj;
cy::Matrix4f model;
cy::Matrix4f view;
cy::Matrix4f projection;
cy::Point3f pos;
cy::Point3f target;
cy::Point3f up;
int r = 0;
int g = 0;
int b = 0;
int shaderVersion = 1;
float transValues[16];
float viewValues[16];
float rotationOrigin = -1;
float zoomOrigin = -1;
float xdelta = 0;
float ydelta = 0;
float rx = 0;
float ry = 0;
float rz = 0;
float zz = 0;
float translationZ = 0;
float xangle = 0;
float xzoom = 0;
//GLuint transID;
//GLuint viewID;

void Idle()
{
	glClearColor(r, g, b, 1.0f);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glutPostRedisplay();
}

void recompileShaders() {
	cout << "Brace yourselves..\n";
	bool success;
	if (shaderVersion == 1) {
		cout << "Loading Vertex Shader B... ";
		success = vertexShaderObj.CompileFile("shader_b.vs", GL_VERTEX_SHADER);
		if (!success) {
			cout << " Load Failed :( Exiting...\n";
			exit(0);
		}
		else
		{
			cout << "success!\n";
		}

		cout << "Loading Fragment Shader B... ";
		success = fragmentShaderObj.CompileFile("shader_b.fs", GL_FRAGMENT_SHADER);
		if (!success) {
			cout << " Load Failed :( Exiting...\n";
			exit(0);
		}
		else
		{
			cout << "success!\n";
		}
		shaderVersion = 2;
		r = 1;
		g = 1;
		b = 1;
	}
	else
	{
		cout << "Loading Vertex Shader A... ";
		success = vertexShaderObj.CompileFile("shader.vs", GL_VERTEX_SHADER);
		if (!success) {
			cout << " Load Failed :( Exiting...\n";
			exit(0);
		}
		else
		{
			cout << "success!\n";
		}

		cout << "Loading Fragment Shader A... ";
		success = fragmentShaderObj.CompileFile("shader.fs", GL_FRAGMENT_SHADER);
		if (!success) {
			cout << " Load Failed :( Exiting...\n";
			exit(0);
		}
		else
		{
			cout << "success!\n";
		}
		shaderVersion = 1;
		r = 0;
		g = 0;
		b = 0;
	}
	ShaderProgram.CreateProgram();
	ShaderProgram.AttachShader(vertexShaderObj);
	ShaderProgram.AttachShader(fragmentShaderObj);

	GLuint progID = ShaderProgram.GetID();
	
	ShaderProgram.Link();
	ShaderProgram.Bind();
	ShaderProgram.RegisterUniforms("trans view");

	glutPostRedisplay();
}

void Display()
{
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	

	projection.SetPerspective(45, 1, 0, .1);
	cy::Matrix4f t;
	cy::Matrix4f v;
	t.SetIdentity();
	v.SetIdentity();

	t = projection * view * model * t;
	v = view * model * v;

	t.Get(transValues);
	v.Get(viewValues);

	ShaderProgram.SetUniformMatrix4(0, transValues);
	ShaderProgram.SetUniformMatrix4(1, viewValues);

	glDrawArrays(GL_TRIANGLES, 0, 3* teapot.NF());

	glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case(27):
		glutLeaveMainLoop();
		break;
	case(GLUT_KEY_F6):
	case(-97):
	case(117):
		cout << "hit!\n";

		break;
	default:
		break;
	}
}

void SpecialKeys(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_F6:
		recompileShaders();
		break;
	default:
		break;
	}
}

//Derived the basic structure of these functions from an article on http://www.lighthouse3d.com
//I'm new to C++ so I don't claim to have thought up the following two functions on my own.
void MousePress(int side, int direction, int x, int y)
{
	if (side == GLUT_LEFT_BUTTON)
	{
		if (direction == GLUT_DOWN)
		{
			rotationOrigin = x;
		}
		else
		{
			rotationOrigin = -1;
			xangle += xdelta;
		}
	}

	if (side == GLUT_RIGHT_BUTTON)
	{
		if (direction == GLUT_DOWN)
		{
			zoomOrigin = x;
		}
		else
		{
			zoomOrigin = -1;
			xzoom += xdelta;
		}
	}
}

void MouseDrag(int x, int y)
{
	if (rotationOrigin >= 0)
	{
		xdelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH;
		cout << "xdelta: " << xdelta;
		ry = xangle + xdelta;

		pos = cyPoint3f(50*cos(ry), 15.0f, 50*sin(ry));
		view.SetView(pos, target, up);
		//model.SetRotationZYX(rx, ry, 0.0f);
		//model.SetTransComponent(cyPoint3f(0, 0, -10));

		glutPostRedisplay();
	}
	else if (zoomOrigin >= 0)
	{
		xdelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH * 5;
		cout << "xdelta: " << xdelta;
		zz = xangle + xdelta;

		view.SetView(cyPoint3f(0,0, 20 + zz), target, cyPoint3f(0, 0, 1));
		glutPostRedisplay();
	}
}

struct VData {
	cyPoint3f position;
	cyPoint3f vertexNormal;
	cyPoint3f surfaceNormal;
};


int main(int argc, char* argv[]) {

	char const* const input = argv[1];

	// Initialize GLUT
	glutInit(&argc, argv);
	// Create Window
	glutInitDisplayMode(GLUT_RGBA | GLUT_ALPHA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(750, 750);
	
	glEnable(GL_DEPTH_TEST);

	glutCreateWindow("Transformations");
    GLenum res = glewInit();

	bool test = teapot.LoadFromFileObj(input);

	/*Rotations, Translations, Perspectives*/
	rx = 0;
	translationZ = -10;
	float pi = 3.141592653589793238462643383279502884197169;

	teapot.ComputeBoundingBox();
	cy::Point3f max = teapot.GetBoundMax();
	cy::Point3f min = teapot.GetBoundMin();
	cyPoint3f center = (max + min) / 2;

	pos = cy::Point3f(0, 15, 50);
	target = cyPoint3f(0, 10, 0);
	up = cy::Point3f(0, 1, 0);

	cy::Matrix4f t;
	cy::Matrix4f v;

	t.SetIdentity();
	v.SetIdentity();

	

	model.SetRotationZYX(0, 0, 0);
	view.SetView(pos, target, up);
	projection.SetPerspective(pi / 2, 1, 1.0, 50);

	//model.SetTransComponent(cyPoint3f(0, 0, translationZ));
	t = projection * view * model * t;
	v = view * model;

	t.Get(transValues);
	v.Get(viewValues);

	v.Invert();
	v.Transpose();
	vector<VData> theGoods(3 * teapot.NF());

	cyPoint3f bc;
	cyTriMesh::TriFace f;
	cyTriMesh::TriFace fn;
	cyPoint3f U;
	cyPoint3f V;
	cyPoint3f N;
	for (int i = 0; i < teapot.NF(); i++) {
		f = teapot.F(i);
		fn = teapot.FN(i);

		for (int j = 0; j < 3; j++) {
			theGoods[3 * i + j].position = teapot.V(f.v[j]);
			//theGoods[3 * i + j].vertexNormal = teapot.VN(fn.v[j]);
			theGoods[3 * i + j].vertexNormal = v.VectorTransform(teapot.VN(fn.v[j]));
			//theGoods[3 * i + j].vertexNormal = teapot.VN(fn.v[j]);
			//theGoods[3 * i + j].surfaceNormal = teapot.GetNormal(f.v[j], teapot.VN(fn.v[j]));
		}

		U = theGoods[3 * i + 1].position - theGoods[3 * i].position;
		V = theGoods[3 * i + 2].position - theGoods[3 * i].position;
		N = cyPoint3f(U.y*V.z - U.z*V.y, U.z*V.x - U.x*V.z, U.x*V.y - U.y*V.x);
		v.VectorTransform(N);

		theGoods[3 * i].surfaceNormal = N.GetNormalized();
		theGoods[3 * i + 1].surfaceNormal = N.GetNormalized();
		theGoods[3 * i + 2].surfaceNormal = N.GetNormalized();
		/*bc = (theGoods[3 * i].position + theGoods[3 * i + 1].position + theGoods[3 * i + 2].position) / 3;
		theGoods[3*i].surfaceNormal = teapot.GetNormal(i, bc);
		theGoods[3 * i + 1].surfaceNormal = theGoods[3 * i].surfaceNormal;
		theGoods[3 * i + 2].surfaceNormal = theGoods[3 * i].surfaceNormal;*/
	}


	
	if (res != GLEW_OK)
	{
		fprintf(stderr, "Error: '%s'\n", glewGetErrorString(res));
		return 1;
	}

	GLuint VAO;
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);
	// Generate 1 buffer using the address of the Global GLuint Object
	GLuint VBO_a, VBO_b;
	glGenBuffers(1, &VBO_a);
	glGenBuffers(1, &VBO_b);

	//Position, Vertex Normals, Surface Normals
	glBindBuffer(GL_ARRAY_BUFFER, VBO_a);
	glBufferData(GL_ARRAY_BUFFER, theGoods.size() * sizeof(VData), theGoods.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VData), 0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VData), (GLvoid*)offsetof(VData, vertexNormal));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(VData), (GLvoid*)offsetof(VData, surfaceNormal));

	//Surface Normals
	//glBindBuffer(GL_ARRAY_BUFFER, VBO_b);
	//glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(cyPoint3f), normals.data(), GL_STATIC_DRAW);
	//glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);


	glBindVertexArray(VAO);

	ShaderProgram.CreateProgram();
	vertexShaderObj.CompileFile("shader.vs", GL_VERTEX_SHADER);
	fragmentShaderObj.CompileFile("shader.fs", GL_FRAGMENT_SHADER);

	ShaderProgram.AttachShader(vertexShaderObj);
	ShaderProgram.AttachShader(fragmentShaderObj);
	GLuint progID = ShaderProgram.GetID();
	
	//transID = glGetUniformLocation(progID, "trans");
	//viewID = glGetUniformLocation(progID, "view");

	ShaderProgram.Link();
	ShaderProgram.Bind();
	ShaderProgram.RegisterUniforms("trans view");


	ShaderProgram.SetUniformMatrix4(0, transValues);
	ShaderProgram.SetUniformMatrix4(1, viewValues);

	//glUniformMatrix4fv(transID, 1, GL_FALSE, transValues);
	//glGetUniformfv(progID, transID, viewValues);
	//glUniformMatrix4fv(viewID, 1, GL_FALSE, &viewValues);


	glutDisplayFunc(Display);
	glutIdleFunc(Idle);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(SpecialKeys);
	glutMouseFunc(MousePress);
	glutMotionFunc(MouseDrag);


	glutPostRedisplay();
	glutMainLoop();
	return 0;
}