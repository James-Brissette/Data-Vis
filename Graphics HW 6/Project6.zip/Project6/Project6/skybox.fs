#version 330 core

in vec3 fragPosition;

out vec4 fcolor;

uniform samplerCube skyBox;

void main()
{
	fcolor = texture(skyBox, fragPosition);
	//fcolor = vec4(1,0,1,1);
}



