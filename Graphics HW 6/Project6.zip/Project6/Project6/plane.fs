#version 330 core
in vec3 fragPosition;
in vec2 texCoord;
in vec4 gl_FragCoord;

out vec4 fcolor;

uniform vec3 cameraPos;
uniform vec3 lightPos;
uniform sampler2D reflection;


void main()
{
	vec3 normals = vec3(0,1,0);
	//vec3 I = normalize(fragPosition - cameraPos);
	//vec3 R = reflect(I, normals);
	//fcolor = vec4(texture(skyBox, vec3(0,1,0)).rgb, 1.0);
	vec4 ambient = texture(reflection, vec2(gl_FragCoord.x / 800, gl_FragCoord.y / 800));

	vec3 lightDir = normalize(lightPos - fragPosition);
	float d = max(dot(normals, lightDir), 0.0);
	vec3 diffuse = d * vec3(0.5,0.5,0.5)*0.5;// 0.2 is too low, 1 is too high

	//Specular Lighting
	vec3 viewDir = normalize(cameraPos - fragPosition);
	vec3 halfDir = normalize(lightDir + viewDir);
	int exp = 64;
	
	//float amp = lightIntensity / length(lightDir);

	float specAngle = max(dot(halfDir, normals), 0.0);
	float specular = pow(specAngle, exp);

	vec4 result = ambient + (diffuse) + (specular * vec3(1, 1, 1))*0.5;
	fcolor = result;
}


