#version 330 core

in vec3 fragPosition;
in vec3 normals;

out vec4 fcolor;

uniform vec3 cameraPos;
uniform vec3 lightPos;
uniform samplerCube skyBox;

void main()
{
	vec3 I = normalize(fragPosition - cameraPos);
	vec3 R = reflect(I, normals);
	vec3 lightDir = normalize(lightPos - fragPosition);

	float d = max(dot(normals, lightDir), 0.0);
	vec3 diffuse = d * vec3(1,1,1);

	//Specular Lighting
	vec3 halfDir = normalize(lightDir + I);
	int exp = 16;
	float specAngle = max(dot(halfDir, normals), 0.0);
	float specular = pow(specAngle, exp);

	vec3 result = (diffuse) * texture(skyBox,R).rgb * vec3(0,0,0) + (specular * texture(skyBox,R).rgb * vec3(0,0,0)); 

	//fcolor = vcolor;
	//fcolor = vec4(0,0,0,0);
	fcolor = vec4(texture(skyBox, R).rgb, 1.0);
}



