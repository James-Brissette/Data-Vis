#include <GL/freeglut.h>
#include <iostream>

using namespace std;
float r = 0;
float g = 0;
float b = 0;

void Idle()
{
	r = fmod(r + 0.001, 1.0);
	g = fmod(g + 0.0025, 1.0);
	b = fmod(b + 0.005, 1.0);

	glClearColor(r, g, b, 1.0f);
	glutPostRedisplay();
}

void Display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case(27):
		glutLeaveMainLoop();
	default:
		break;
	}
}


int main(int argc, char* argv[]) {

	// Initialize GLUT
	glutInit(&argc, argv);
	// Create Window
	glutInitDisplayMode(GL_RGB | GL_DOUBLE);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Hello World");
	
	//Link Functions
	glutDisplayFunc(Display);
	glutIdleFunc(Idle);
	glutKeyboardFunc(Keyboard);


	glutMainLoop();
	return 0;
}