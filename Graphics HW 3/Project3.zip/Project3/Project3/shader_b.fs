#version 330 core

in vec4 vcolor;
out vec4 fcolor;

void main()
{
	fcolor = vcolor;
}