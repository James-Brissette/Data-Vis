#version 330 core
in vec4 vcolor;
in vec3 fragPosition;
in vec3 normals;
in vec2 texCoord;


out vec4 fcolor;
uniform vec3 lightPos;
uniform vec3 lightColor;
uniform vec3 objColor;
uniform vec3 viewPos;
uniform vec3 Ka;
uniform vec3 Kd;
uniform vec3 Ks;
uniform sampler2D texture0;
uniform sampler2D texture1;

const int lightIntensity = 10;

void main()
{
	
	//Ambient Lighting
	//vec3 ambient = 0.1* lightColor;
	vec3 ambient = Ka * 0.2;

	//Diffuse Lighting
	vec3 lightDir = normalize(lightPos - fragPosition);
	float d = max(dot(normals, lightDir), 0.0);
	//vec3 diffuse = d * lightColor;
	vec3 diffuse = d * Kd;

	//Specular Lighting
	vec3 viewDir = normalize(viewPos - fragPosition);
	vec3 halfDir = normalize(lightDir + viewDir);
	float s = 1;
	int exp = 16;
	
	float amp = lightIntensity / length(lightDir);

	float specAngle = max(dot(halfDir, normals), 0.0);
	//vec3 refDir = reflect(-lightDir, normals);
	//float spec = pow(max(dot(viewDir, refDir), 0.0), exp);
	float specular = pow(specAngle, exp);

	vec3 result = (ambient + diffuse) * texture(texture0,texCoord) + (specular * Ks * texture(texture1,texCoord))*1.5; 

	//fcolor = vcolor;
	//fcolor = vec4(result, 1);
	fcolor = vec4(result, 1);
}



