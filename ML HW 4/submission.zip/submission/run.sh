#set -o nounset
python3 hw2.py > out.txt
exit 0