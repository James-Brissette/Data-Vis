The code written for HW2 was designed to be as easy as possible to run.

simply execute the file using python3 and it will print to the console the results of each cross validation and test for each variant:

python3 hw2.py

The python script contains:
    - 5 perceptron variants
    - 5 cross-validation functions
    - 5 test functions
    - 1 data loading function
    - 1 prediction function

