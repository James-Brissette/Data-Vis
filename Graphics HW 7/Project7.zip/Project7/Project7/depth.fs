#version 330 core

out float fcolor;

void main()
{
	//No need to color any fragments
}


