#version 330 core

out vec4 fcolor;


void main()
{
	fcolor = vec4(1,1,1,1);
}


