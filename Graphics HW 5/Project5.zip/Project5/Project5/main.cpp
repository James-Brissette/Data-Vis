#include <GL/glew.h>
#include <GL/freeglut.h>
#include <iostream>
#include <cyCore.h>
#include <cyPoint.h>
#include <cyMatrix.h>
#include <cyTriMesh.h>
#include <cyGL.h>
#include <lodepng.h>

using namespace std;

cy::TriMesh teapot;
cy::GLSLProgram ShaderProgram;
cy::GLSLShader vertexShaderObj;
cy::GLSLShader fragmentShaderObj;
cy::GLSLProgram planeProgram;
cy::GLSLShader planeVS;
cy::GLSLShader planeFS;
cy::Matrix4f model, planeModel;
cy::Matrix4f view, planeView;
cy::Matrix4f projection, planeProjection;
cy::Point3f pos, planePos;
cy::Point3f lightPos, planeLightPos;
cy::Point3f target, planeTarget;
cy::Point3f up;
cy::TriMesh::Mtl m;
cy::GLRenderTexture<GL_TEXTURE_2D> renderTex;
cy::GLRenderBuffer<GL_TEXTURE_2D> renderBuffer;
float r = 0;
float g = 0;
float b = 0;
int shaderVersion = 1;
float transValues[16];
float viewValues[16];
float rotationOrigin = -1;
float zoomOrigin = -1;
float xdelta = 0, planeXDelta = 0;
float lightDelta = 0, planeLightDelta = 0;
float rx = 0;
float ry = 0;
float lightRy = 0, planeLightRy = 0;
float rz = 0;
float zz = 0;
float translationZ = 0;
float xangle = 0, planeXAngle = 0;
float lightAngle = 0, planeLightAngle = 0;
float xzoom = 0, planeXZoom = 0;
GLuint VAO[2];
GLuint VBO[2];
GLuint bufferID;

//Texture Variables
std::vector<unsigned char> image0;
std::vector<unsigned char> image1;
unsigned tex0Width, tex0Height;
unsigned tex1Width, tex1Height; 
unsigned int texture0;
unsigned int texture1;

//GLuint transID;
//GLuint viewID;

void updateTex();
void Idle()
{
	glClearColor(r, g, b, 1.0f);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glutPostRedisplay();
}

void recompileShaders() {
	cout << "Live Recompile Disabled\n";
	bool enabled = true;
	bool success;

	if (enabled) {
		if (shaderVersion == 1) {
			//cout << "Loading Vertex Shader B... ";
			success = vertexShaderObj.CompileFile("shader_b.vs", GL_VERTEX_SHADER);
			if (!success) {
				cout << " Load Failed :( Exiting...\n";
				//exit(0);
			}
			else
			{
				//cout << "success!\n";
			}

			//cout << "Loading Fragment Shader B... ";
			success = fragmentShaderObj.CompileFile("shader_b.fs", GL_FRAGMENT_SHADER);
			if (!success) {
				cout << " Load Failed :( Exiting...\n";
				//exit(0);
			}
			else
			{
				//cout << "success!\n";
			}
			shaderVersion = 2;
			ShaderProgram.SetUniform(2, lightPos);
			//r = 1;
			//g = 1;
			//b = 1;
		}
		else
		{
			//cout << "Loading Vertex Shader A... ";
			success = vertexShaderObj.CompileFile("shader.vs", GL_VERTEX_SHADER);
			if (!success) {
				cout << " Load Failed :( Exiting...\n";
				//exit(0);
			}
			else
			{
				//cout << "success!\n";
			}

			//cout << "Loading Fragment Shader A... ";
			success = fragmentShaderObj.CompileFile("shader.fs", GL_FRAGMENT_SHADER);
			if (!success) {
				cout << " Load Failed :( Exiting...\n";
				//exit(0);
			}
			else
			{
				//cout << "success!\n";
			}
			shaderVersion = 1;
			ShaderProgram.SetUniform(2, planeLightPos);
			//r = 0;
			//g = 0;
			//b = 0;
		}
		ShaderProgram.CreateProgram();
		ShaderProgram.AttachShader(vertexShaderObj);
		ShaderProgram.AttachShader(fragmentShaderObj);

		GLuint progID = ShaderProgram.GetID();

		ShaderProgram.Link();
		ShaderProgram.Bind();
		ShaderProgram.RegisterUniforms("trans view lightPos lightColor objColor viewPos texture0 texture1 texture2 Ka Kd Ks");

		ShaderProgram.SetUniform(6, 0);
		ShaderProgram.SetUniform(7, 1);
		ShaderProgram.SetUniform(8, 2);

		ShaderProgram.SetUniform(9, (cyPoint3f)m.Ka);
		ShaderProgram.SetUniform(10, (cyPoint3f)m.Kd);
		ShaderProgram.SetUniform(11, (cyPoint3f)m.Ks);

		glutPostRedisplay();
	}
}

void Display()
{
	glBindVertexArray(VAO[1]);
	planeProgram.Bind();

	cy::Matrix4f t;
	cy::Matrix4f v;
	t.SetIdentity();
	t.SetScale(cyPoint3f(.5, .5, .5));
	v.SetIdentity();

	t = planeProjection * planeView * planeModel * t;
	v = planeView * planeModel * v;

	t.Get(transValues);
	v.Get(viewValues);

	planeProgram.SetUniformMatrix4(0, transValues);
	planeProgram.SetUniform(1, 2);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case(27):
		glutLeaveMainLoop();
		break;
	case(GLUT_KEY_F6):
	case(-97):
	case(117):
		cout << "hit!\n";

		break;
	default:
		break;
	}
}

void SpecialKeys(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_F6:
		recompileShaders();
		break;
	default:
		break;
	}
}

void MousePress(int side, int direction, int x, int y)
{
	if (side == GLUT_LEFT_BUTTON)
	{
		if (direction == GLUT_DOWN)
		{
			rotationOrigin = x;
		}
		else
		{
			rotationOrigin = -1;
			xangle += xdelta;
			planeXAngle += planeXDelta;

			lightAngle += lightDelta;
			planeLightAngle += planeLightDelta;
		}

	}

	if (side == GLUT_RIGHT_BUTTON)
	{
		if (direction == GLUT_DOWN)
		{
			zoomOrigin = x;
		}
		else
		{
			zoomOrigin = -1;
			xzoom += xdelta;
			planeXZoom += planeXDelta;
		}
	}
}

void MouseDrag(int x, int y)
{
	if (glutGetModifiers() == 2)
	{
		lightDelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH;
		xdelta = 0;
		lightRy = lightAngle + lightDelta;

		lightPos = cyPoint3f(30 * cos(lightRy), 30.0f, 30 * sin(lightRy));
		ShaderProgram.SetUniform(2, lightPos);
		updateTex();
	}
	else if (glutGetModifiers() == 4) //ALT KEY PRESSED DURING DRAG
	{
		if (rotationOrigin >= 0) //Control Rotation on left click
		{
			planeXDelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH;
			planeLightDelta = 0;
			ry = planeXAngle + planeXDelta;

			planePos = cyPoint3f(15 * cos(ry), 10.0f, 15 * sin(ry));
			planeView.SetView(planePos, planeTarget, up);
			//model.SetRotationZYX(rx, ry, 0.0f);
			//model.SetTransComponent(cyPoint3f(0, 0, -10));

			glutPostRedisplay();
		}
		else if (zoomOrigin >= 0) //Control Zoom on right click
		{
			planeXDelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH * 5;
			zz = planeXAngle + planeXDelta;

			planePos = cyPoint3f(15 * cos(ry), 10.0f, 15 * sin(ry) + 10 * zz);
			planeView.SetView(planePos, planeTarget, up);
			glutPostRedisplay();
		}	
		
	}
	else if (rotationOrigin >= 0)
	{
		xdelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH;
		lightDelta = 0;
		//cout << "xdelta: " << xdelta;
		ry = xangle + xdelta;

		pos = cyPoint3f(15 * cos(ry), 10.0f, 15 * sin(ry));
		view.SetView(pos, target, up);
		//model.SetRotationZYX(rx, ry, 0.0f);
		//model.SetTransComponent(cyPoint3f(0, 0, -10));


		glBindBuffer(GL_ARRAY_BUFFER, VAO[0]);
		updateTex();
	}
	else if (zoomOrigin >= 0)
	{
		xdelta = (x - rotationOrigin) / GLUT_SCREEN_WIDTH * 5;
		//cout << "xdelta: " << xdelta;
		zz = xangle + xdelta;

		pos = cyPoint3f(15 * cos(ry), 10.0f, 15 * sin(ry) + 10 * zz);
		view.SetView(pos, target, up);

		updateTex();
	}
}

void updateBgColor(float rd, float gn, float bl) {
	r = rd;
	g = gn;
	b = bl;
}

void resetTextures() {
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture0);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tex0Width, tex0Height, 0, GL_RGBA, GL_UNSIGNED_BYTE, &image0[0]);
	glGenerateMipmap(GL_TEXTURE_2D);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, texture1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tex1Width, tex1Height, 0, GL_RGBA, GL_UNSIGNED_BYTE, &image1[0]);
	glGenerateMipmap(GL_TEXTURE_2D);
}

void updateTex() {

	renderTex.Bind();
	renderTex.BindTexture(2);

	updateBgColor(0.2, 0.2, 0.2);
	glClearColor(r, g, b, 1.0f);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::;
	cy::Matrix4f t;
	t.SetIdentity();

	//TEAPOT
	glBindVertexArray(VAO[0]);
	ShaderProgram.Bind();
	model.SetIdentity();
	t.SetScale(cyPoint3f(.5, .5, .5));
	t = projection * view * model * t;
	t.Get(transValues);

	cy::Matrix4f v;
	v.SetIdentity();
	v = view * model * v;
	v.Get(viewValues);

	ShaderProgram.SetUniformMatrix4(0, transValues);
	ShaderProgram.SetUniformMatrix4(1, viewValues);
	ShaderProgram.SetUniform(5, pos);

	glDrawArrays(GL_TRIANGLES, 0, 3 * teapot.NF());

	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::;

	bufferID = renderTex.GetID();

	renderTex.Unbind();
	view.SetView(planePos, planeTarget, up);

	updateBgColor(0, 0, 0);
	glutPostRedisplay();
}

struct VData {
	cyPoint3f position;
	cyPoint3f vertexNormal;
	cyPoint3f surfaceNormal;
	cyPoint3f texCoord;
};

struct Plane {
	cyPoint3f position;
	cyPoint3f texCoord;
};

int main(int argc, char* argv[]) {

	char const* const input = argv[1];

	// Initialize GLUT
	glutInit(&argc, argv);
	// Create Window
	glutInitDisplayMode(GLUT_RGBA | GLUT_ALPHA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(800, 800);
	glutInitContextVersion(4, 2);
	glutInitContextProfile(GLUT_CORE_PROFILE);

	//glDisable(GL_CULL_FACE);
	//glCullFace(GL_FALSE);

	glDepthFunc(GL_LEQUAL);

	glutCreateWindow("Transformations");
	
	GLenum res = glewInit();

	glGetString(GL_VERSION);

	if (res != GLEW_OK)
	{
		fprintf(stderr, "Error: '%s'\n", glewGetErrorString(res));
		return 1;
	}

	bool test = teapot.LoadFromFileObj(input);


	/*Rotations, Translations, Perspectives*/
	rx = 0;
	translationZ = -10;
	float pi = 3.141592653589793238462643383279502884197169;

	teapot.ComputeBoundingBox();
	cy::Point3f max = teapot.GetBoundMax();
	cy::Point3f min = teapot.GetBoundMin();
	cyPoint3f center = (max + min) / 2;

	pos = cy::Point3f(0, 10, 15);
	planePos = pos;
	target = center*.5;// cyPoint3f(0, 5, 0);
	planeTarget = target;
	up = cy::Point3f(0, 1, 0);

	cy::Matrix4f t;
	cy::Matrix4f v;

	t.SetIdentity();
	t.SetScale(cyPoint3f(.7, .7, .7));
	v.SetIdentity();


	model.SetRotationZYX(0, 0, 0);
	planeModel.SetRotationZYX(0, 0, 0);
	view.SetView(pos, target, up);
	planeView.SetView(planePos, planeTarget, up);
	projection.SetPerspective(pi / 2, 1.0f, 1.0f, 40.0f);
	planeProjection.SetPerspective(pi / 2, 1.0f, 1.0f, 40.0f);

	//model.SetTransComponent(cyPoint3f(0, 0, translationZ));
	t = projection * view * model * t;
	v = view * model;

	t.Get(transValues);
	v.Get(viewValues);

	v.Invert();
	v.Transpose();



	//TEAPOT
	vector<VData> theGoods(3 * teapot.NF());

	cyPoint3f bc;
	cyTriMesh::TriFace f;
	cyTriMesh::TriFace fn;
	cyTriMesh::TriFace ft;
	cyPoint3f U;
	cyPoint3f V;
	cyPoint3f N;
	for (int i = 0; i < teapot.NF(); i++) {
		f = teapot.F(i);
		fn = teapot.FN(i);
		ft = teapot.FT(i);

		for (int j = 0; j < 3; j++) {
			theGoods[3 * i + j].position = teapot.V(f.v[j]);
			theGoods[3 * i + j].vertexNormal = v.VectorTransform(teapot.VN(fn.v[j])).GetNormalized();

			theGoods[3 * i + j].texCoord = teapot.VT(ft.v[j]);
		}

		U = theGoods[3 * i + 1].position - theGoods[3 * i].position;
		V = theGoods[3 * i + 2].position - theGoods[3 * i].position;
		N = cyPoint3f(U.y*V.z - U.z*V.y, U.z*V.x - U.x*V.z, U.x*V.y - U.y*V.x);
		v.VectorTransform(N);

		theGoods[3 * i].surfaceNormal = N.GetNormalized();
		theGoods[3 * i + 1].surfaceNormal = N.GetNormalized();
		theGoods[3 * i + 2].surfaceNormal = N.GetNormalized();
	}


	//PLANE
	vector<Plane> plane(6);
	plane[0].position = cyPoint3f(-10, 2, 10);
	plane[0].texCoord = cyPoint3f(0, 0, 0);
	plane[1].position = cyPoint3f(10, 2, 10);
	plane[1].texCoord = cyPoint3f(1, 0, 0);
	plane[2].position = cyPoint3f(10, 22, 2);
	plane[2].texCoord = cyPoint3f(1, 1, 0);
	plane[3].position = cyPoint3f(10, 22, 2);
	plane[3].texCoord = cyPoint3f(1, 1, 0);
	plane[4].position = cyPoint3f(-10, 22, 2);
	plane[4].texCoord = cyPoint3f(0, 1, 0);
	plane[5].position = cyPoint3f(-10, 2, 10);
	plane[5].texCoord = cyPoint3f(0, 0, 0);

	vector<cyPoint3f> textureVertices;

	
	glGenVertexArrays(2, VAO);
	glGenBuffers(2, VBO);

	glBindVertexArray(VAO[0]); 
	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
	glBufferData(GL_ARRAY_BUFFER, theGoods.size() * sizeof(VData), theGoods.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VData), 0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VData), (GLvoid*)offsetof(VData, texCoord)); 
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(VData), (GLvoid*)offsetof(VData, vertexNormal));
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VData), (GLvoid*)offsetof(VData, surfaceNormal));
	
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glEnableVertexAttribArray(3);

	glBindVertexArray(VAO[1]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
	glBufferData(GL_ARRAY_BUFFER, plane.size() * sizeof(Plane), plane.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Plane), 0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Plane), (GLvoid*)offsetof(Plane, texCoord));
	
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);



	glBindVertexArray(VAO[0]);
	glEnable(GL_DEPTH_TEST);


	//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

	planeProgram.CreateProgram();
	planeVS.CompileFile("shader.vs", GL_VERTEX_SHADER);
	planeFS.CompileFile("shader.fs", GL_FRAGMENT_SHADER);
	planeProgram.AttachShader(planeVS);
	planeProgram.AttachShader(planeFS);
	planeProgram.Link();
	planeProgram.Bind();
	planeProgram.RegisterUniforms("trans texture2");


	ShaderProgram.CreateProgram();
	vertexShaderObj.CompileFile("shader_b.vs", GL_VERTEX_SHADER);
	fragmentShaderObj.CompileFile("shader_b.fs", GL_FRAGMENT_SHADER);
	ShaderProgram.AttachShader(vertexShaderObj);
	ShaderProgram.AttachShader(fragmentShaderObj);
	GLuint progID = ShaderProgram.GetID();


	ShaderProgram.Link();
	ShaderProgram.Bind();
	ShaderProgram.RegisterUniforms("trans view lightPos lightColor objColor viewPos texture0 texture1 texture2 Ka Kd Ks");


	ShaderProgram.SetUniformMatrix4(0, transValues);
	ShaderProgram.SetUniformMatrix4(1, viewValues);

	lightPos = cyPoint3f(2 * 30.0 / cy::cySqrt(2), 30.0, 2 * 30.0 / cy::cySqrt(2));
	ShaderProgram.SetUniform(2, lightPos);
	ShaderProgram.SetUniform(3, 1.0f, 1.0f, 1.0f);

	cyPoint3f objColor = cyPoint3f(0.8f, 0, 0);
	ShaderProgram.SetUniform(4, objColor.x, objColor.y, objColor.z);
	ShaderProgram.SetUniform(5, pos);



	/*:::::::::::::::::::::::::::: Textures ::::::::::::::::::::::::::::*/
	
	unsigned error = lodepng::decode(image0, tex0Width, tex0Height, "brick.png");
	if (error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;

	error = lodepng::decode(image1, tex1Width, tex1Height, "brick-specular.png");
	if (error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glGenTextures(1, &texture0);
	glGenTextures(1, &texture1);

	resetTextures();
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	
	m = teapot.M(0);

	ShaderProgram.SetUniform(6, 0);
	ShaderProgram.SetUniform(7, 1);
	ShaderProgram.SetUniform(8, 2);

	ShaderProgram.SetUniform(9, (cyPoint3f)m.Ka);
	ShaderProgram.SetUniform(10, (cyPoint3f)m.Kd);
	ShaderProgram.SetUniform(11, (cyPoint3f)m.Ks);

	cout << "Ka: (" << m.Ka[0] << "," << m.Ka[1] << "," << m.Ka[2] << ")" << endl;
	cout << "Kd: (" << m.Kd[0] << "," << m.Kd[1] << "," << m.Kd[2] << ")" << endl;
	cout << "Ks: (" << m.Ks[0] << "," << m.Ks[1] << "," << m.Ks[2] << ")" << endl;

	/*:::::::::::::::: RenderTexture ::::::::::::::::*/

	res = renderTex.Initialize(true, 4, 800, 800);
	if (!res) {
		cout << "RenderBuffer failed to Initialize\n " << endl;
	}
	updateTex();

	/*:::::::::::::::::::::::::::::::::::::::::::::::*/



	//Good Practice
	glBindVertexArray(VAO[1]);

	glutDisplayFunc(Display);
	glutIdleFunc(Idle);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(SpecialKeys);
	glutMouseFunc(MousePress);
	glutMotionFunc(MouseDrag);


	glutPostRedisplay();
	glutMainLoop();
	return 0;
}