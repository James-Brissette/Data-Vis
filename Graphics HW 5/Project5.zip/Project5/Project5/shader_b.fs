#version 330 core

in vec3 fragPosition;
in vec2 texCoord;
in vec3 normals;


out vec4 fcolor;
uniform vec3 lightPos;
uniform vec3 lightColor;
uniform vec3 objColor;
uniform vec3 viewPos;
uniform vec3 Ka;
uniform vec3 Kd;
uniform vec3 Ks;
uniform sampler2D texture0;
uniform sampler2D texture1;
uniform sampler2D texture2;

const int lightIntensity = 10;

void main()
{
	
	//Ambient Lighting
	vec3 ambient = vec3(1,1,1);

	//Diffuse Lighting
	vec3 lightDir = normalize(lightPos - fragPosition);
	float d = max(dot(normals, lightDir), 0.0);
	vec3 diffuse = d * vec3(1,1,1) * .8;

	//Specular Lighting
	vec3 viewDir = normalize(viewPos - fragPosition);
	vec3 halfDir = normalize(lightDir + viewDir);
	
	int exp = 16;
	
	//float amp = lightIntensity / length(lightDir);

	float specAngle = max(dot(halfDir, normals), 0.0);
	float specular = pow(specAngle, exp);

	vec3 result = (ambient + diffuse) * texture(texture0,texCoord) + (specular * Ks * texture(texture1,texCoord))*.5; 

	//fcolor = vec4(1.0,1.0,1.0,1.0);
	fcolor = vec4(result,1);
	//fcolor = vec4(1,0,0,0) * texture(texture0,texCoord);
}



