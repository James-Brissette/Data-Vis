#version 330 core

in vec3 fragPosition;
in vec2 texCoord;


out vec4 fcolor;

uniform sampler2D texture2;


void main()
{
	fcolor = texture(texture2,texCoord);
}



