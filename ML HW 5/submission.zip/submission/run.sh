#set -o nounset
python3 hw5.py > out.txt
exit 0